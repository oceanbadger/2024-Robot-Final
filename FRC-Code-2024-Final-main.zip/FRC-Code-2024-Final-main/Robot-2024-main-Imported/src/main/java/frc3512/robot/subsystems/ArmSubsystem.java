package frc3512.robot.subsystems;

import com.revrobotics.CANSparkBase.IdleMode;
import com.revrobotics.CANSparkFlex;
import com.revrobotics.CANSparkLowLevel.MotorType;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj.DutyCycleEncoder;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc3512.robot.Constants;

public class ArmSubsystem extends SubsystemBase {
    private CANSparkFlex leftMotor;
    private CANSparkFlex rightMotor;
    private DutyCycleEncoder armEncoder;
    private double encoderOffset = 0.7510;
    private PIDController pidController;

    

    public ArmSubsystem() {
        leftMotor = new CANSparkFlex(35, MotorType.kBrushless);
        rightMotor = new CANSparkFlex(36, MotorType.kBrushless);
        armEncoder = new DutyCycleEncoder(9);
        armEncoder.setPositionOffset(encoderOffset);

        pidController = new PIDController(Constants.ArmConstants.kP,
            Constants.ArmConstants.kI,
            Constants.ArmConstants.kD);
        
        pidController.setTolerance(0.002);

        leftMotor.restoreFactoryDefaults();
        rightMotor.restoreFactoryDefaults();

        //CANSparkMaxUtil.setCANSparkMaxBusUsage(leftMotor, Usage.kMinimal);
        //CANSparkMaxUtil.setCANSparkMaxBusUsage(rightMotor, Usage.kPositionOnly);

        leftMotor.setSmartCurrentLimit(Constants.ArmConstants.currentLimit);
        rightMotor.setSmartCurrentLimit(Constants.ArmConstants.currentLimit);

        leftMotor.setIdleMode(IdleMode.kCoast);
        rightMotor.setIdleMode(IdleMode.kCoast);

        rightMotor.setInverted(false);
        leftMotor.setInverted(false);

        rightMotor.burnFlash();
        leftMotor.burnFlash();

        setPower(0);

    }

    @Override
    public void periodic() {
        SmartDashboard.putNumber("armEncoder", getPosition());
        SmartDashboard.putNumber("arm motor encoder position", leftMotor.getEncoder().getPosition()*1.2);
        //System.out.println(getPosition());
    }

    /**
     * 
     * @return rotations
     */
    public double getRawPosition() {
        return armEncoder.getAbsolutePosition();
    }
    /**
     * 
     * @return degrees
     */
    public double getPosition() {
        // SmartDashboard.putNumber("raw absolute position", armEncoder.getAbsolutePosition());
        // return ((armEncoder.getAbsolutePosition() - armEncoder.getPositionOffset())*360.0) % 360.0;
        return leftMotor.getEncoder().getPosition()*1.2;
    }

    public void setPower(double power) {
        leftMotor.set(power);
        rightMotor.set(-power);
    }

    /*
    public void setPosition(double setpoint) {
        setPower(pidController.calculate(getPosition(), setpoint));
    }
    */
    
}
