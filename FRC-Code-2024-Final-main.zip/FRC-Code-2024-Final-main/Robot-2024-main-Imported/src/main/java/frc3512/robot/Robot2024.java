package frc3512.robot;

import com.pathplanner.lib.auto.NamedCommands;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.InstantCommand;
import edu.wpi.first.wpilibj2.command.RunCommand;
import edu.wpi.first.wpilibj2.command.StartEndCommand;
import edu.wpi.first.wpilibj2.command.WaitCommand;
import frc3512.robot.subsystems.Superstructure;
import frc3512.robot.subsystems.ArmPositionCommand;

public class Robot2024 {
  private final Superstructure superstructure = new Superstructure();

  public Robot2024() {
    // Configure the trigger and axis bindings
    configureBindings();
    configureAxisActions();

    // NamedCommands.registerCommand("Shoot", new RunCommand(
    //     () -> new ArmPositionCommand(superstructure.arm, Constants.ArmConstants.middlePosition).andThen(
    //         () -> new WaitCommand(2).alongWith(new InstantCommand(() -> superstructure.shootake.shootClose()).andThen(
    //             new WaitCommand(4).alongWith(new InstantCommand(() -> superstructure.shootake.i_wanna_intake()))))))
    //     .andThen(() ->  new InstantCommand(() -> superstructure.shootake.stopShooting())
    //         .alongWith(new InstantCommand(() -> superstructure.shootake.i_dont_wanna_intake()))));
  }

  private void configureBindings() {
    superstructure.configureBindings();
  }

  private void configureAxisActions() {
    superstructure.configureAxisActions();
  }

  public void setDriveMode() {
  }

  public void setMotorBrake(boolean brake) {
    superstructure.setMotorBrake(brake);
  }

  public Command getAutonomousCommand() {
    // return new RunCommand(
    //     () -> new ArmPositionCommand(superstructure.arm, Constants.ArmConstants.middlePosition)).andThen(
    //     () -> new WaitCommand(2).alongWith(new InstantCommand(() -> superstructure.shootake.shootClose()))).andThen(
    //     () -> new WaitCommand(4).alongWith(new InstantCommand(() -> superstructure.shootake.i_wanna_intake())))))
    //     .andThen(() ->  new InstantCommand(() -> superstructure.shootake.stopShooting())
    //         .alongWith(new InstantCommand(() -> superstructure.shootake.i_dont_wanna_intake()))
    // .andThen(() ->
    return superstructure.getAuton();
  }

  public void zeroGyro() {
    superstructure.swerve.zeroGyro();
  }

  public void invertRobot() {
    superstructure.swerve
        .resetOdometry(new Pose2d(superstructure.swerve.getPose().getTranslation(), Rotation2d.fromDegrees(180)));
  }
}
