package frc3512.robot.subsystems;

import com.revrobotics.CANSparkBase.IdleMode;
import com.revrobotics.CANSparkLowLevel;
import com.revrobotics.CANSparkLowLevel.MotorType;
import com.revrobotics.CANSparkMax;
import edu.wpi.first.math.controller.ProfiledPIDController;
import edu.wpi.first.math.trajectory.TrapezoidProfile;
import edu.wpi.first.wpilibj.DutyCycleEncoder;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.ProfiledPIDSubsystem;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc3512.lib.util.CANSparkMaxUtil;
import frc3512.lib.util.CANSparkMaxUtil.Usage;
import frc3512.robot.Constants;
import frc3512.robot.Constants.ElevatorConstants;

//import edu.wpi.first.wpilibj.motorcontrol.MotorControllerGroup;

/*public class Elevator extends ProfiledPIDSubsystem {
  private CANSparkMax elevatorMotor = new CANSparkMax(13, MotorType.kBrushless);
  private CANSparkMax elevatorMotor2 = new CANSparkMax(14, MotorType.kBrushless);

*/


  //private final MotorControllerGroup elevatorGroup = 
    //new MotorControllerGroup(elevatorMotor, elevatorMotor2);


  // undo this private DutyCycleEncoder elevatorEncoder = new DutyCycleEncoder(1);
  //private DutyCycleEncoder elevatorEncoder2 = new DutyCycleEncoder(1);
  /* 1 is absolute, 2 is a, 3 is b, 4 is incremental */

  //boolean bypassStop = false;

  //public Elevator() {
    //super(
        //new ProfiledPIDController(
            //ElevatorConstants.kP,
            //ElevatorConstants.kI,
            //ElevatorConstants.kD,
            //new TrapezoidProfile.Constraints(
                //ElevatorConstants.kMaxVelocityRadPerSecond,
                //ElevatorConstants.kMaxAccelerationRadPerSecSquared)));
    //getController().setTolerance(0.01);
    //setGoal(ElevatorConstants.stowPosition);

    //elevatorMotor.restoreFactoryDefaults();
    //elevatorMotor2.restoreFactoryDefaults();

    //CANSparkMaxUtil.setCANSparkMaxBusUsage(elevatorMotor, Usage.kPositionOnly);
    //CANSparkMaxUtil.setCANSparkMaxBusUsage(elevatorMotor2, Usage.kPositionOnly);

    //elevatorMotor.setIdleMode(IdleMode.kBrake);
    //elevatorMotor2.setIdleMode(IdleMode.kBrake);
    //elevatorMotor.setSmartCurrentLimit(Constants.ElevatorConstants.currentLimit);
    //elevatorMotor2.setSmartCurrentLimit(Constants.ElevatorConstants.currentLimit);
    //elevatorMotor.enableVoltageCompensation(10);
    //elevatorMotor2.enableVoltageCompensation(10);
    //elevatorMotor.setInverted(false);
    //elevatorMotor2.setInverted(false);
    //elevatorMotor2.follow(elevatorMotor);

    

    


    //elevatorMotor.burnFlash();
    //elevatorMotor2.burnFlash();

    //elevatorGroup.set(0);

    //SmartDashboard.putNumber("Elevator Encoder", elevatorEncoder.getDistance());
    //SmartDashboard.putNumber("Elevator PID Setpoint", getController().getGoal().position);
    //SmartDashboard.putNumber("Elevator/ P", ElevatorConstants.kP);

    //elevatorEncoder.setDistancePerPulse(Constants.ElevatorConstants.distancePerPulse);
    //elevatorEncoder.setSamplesToAverage(Constants.ElevatorConstants.averageSampleSize);

    //elevatorEncoder.reset();
    //elevatorEncoder2.reset();
  //}

  //@Override
  //public void useOutput(double output, TrapezoidProfile.State setpoint) {
    //elevatorMotor.setVoltage(output);
    //elevatorMotor2.setVoltage(output);
  //}


  //@Override
  //public double getMeasurement() {
    //return elevatorEncoder.getDistance();
    
  //}

  //public void moveElevator(double speed) {
    //if (elevatorEncoder.getDistance() <= 0.49 && elevatorEncoder.getDistance() >= -4.25) {
      //elevatorMotor.set(speed);
      //elevatorMotor2.set(speed);
    //} else if (elevatorEncoder.getDistance() >= 0.49 && speed > 0) {
      //bypassStop = true;
      //elevatorMotor.set(speed);
      //elevatorMotor2.set(speed);
    //} else if (elevatorEncoder.getDistance() <= -4.25 && speed < 0) {
      //bypassStop = true;
      //elevatorMotor.set(speed);
      //elevatorMotor2.set(speed);
    //}
  //}

 

  //public void stowElevator() {
    //setGoal(ElevatorConstants.stowPosition);
    //enable();
  //}

  //public void outElevator() {
    //setGoal(ElevatorConstants.outPosition);
    //enable();
  //}

  //public void stopElevator() {
    //elevatorMotor.set(0);
    //elevatorMotor2.set(0);
    //disable();
  //}

  //@Override
  //public void periodic() {
    //super.periodic();
    //if ((elevatorEncoder.getDistance() >= 0.49 || elevatorEncoder.getDistance() <= -4.25)
        //&& !bypassStop) {
      //stopElevator();
    //} else if (elevatorEncoder.getDistance() <= 0.49 && elevatorEncoder.getDistance() >= -4.25) {
      //bypassStop = false;
    //}
    //SmartDashboard.putNumber("Elevator/ Encoder", elevatorEncoder.getDistance());
    //SmartDashboard.putNumber("Elevator/ PID Setpoint", getController().getGoal().position);
    //SmartDashboard.putNumber("Elevator/ P", ElevatorConstants.kP);
 // }
//}
