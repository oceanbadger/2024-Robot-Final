package frc3512.robot.subsystems;

import edu.wpi.first.math.controller.ArmFeedforward;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj2.command.Command;
import frc3512.robot.Constants;

public class ArmPositionCommand extends Command {
    private ArmSubsystem arm;
    private double setpoint;
    private PIDController pid;
    private ArmFeedforward ff;

    public ArmPositionCommand(ArmSubsystem arm, double setpoint) {
        this.arm = arm;
        this.setpoint = setpoint;
        pid = new PIDController(Constants.ArmConstants.kP, Constants.ArmConstants.kI, Constants.ArmConstants.kD);
        pid.setTolerance(Constants.ArmConstants.positionTolerance);
        pid.enableContinuousInput(0.0, 360.0);
        ff = new ArmFeedforward(0.0, 0.0, 0.0);
        addRequirements(arm);

    }

    @Override
    public void initialize() {

    }

    @Override
    public boolean isFinished() {
        return pid.atSetpoint();
    }

    @Override
    public void execute() {
        
        arm.setPower(pid.calculate(arm.getPosition(), setpoint) + ff.calculate(Units.degreesToRadians(setpoint), 0.0));
        //System.out.println("ahhh");
    }

    @Override
    public void end(boolean inturrpted) {
        System.out.println("arm position reached");
        arm.setPower(0.0);
    }
    
}
