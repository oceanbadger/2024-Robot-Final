package frc3512.robot.subsystems;

import com.revrobotics.CANSparkBase.IdleMode;
//import com.revrobotics.CANSparkFlex;
import com.revrobotics.CANSparkMax;
import com.revrobotics.CANSparkLowLevel.MotorType;
import com.revrobotics.CANSparkLowLevel;
import edu.wpi.first.wpilibj2.command.Command;
import frc3512.lib.util.CANSparkMaxUtil;
import frc3512.lib.util.CANSparkMaxUtil.Usage;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj.DutyCycleEncoder;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc3512.robot.Constants;




// COmpletely unfinished
public class Intake extends SubsystemBase {
    private CANSparkMax intakeMotor = 
    new CANSparkMax(
        Constants.IntakeConstants.intakeMotorID, CANSparkLowLevel.MotorType.kBrushless);

    //private CANSparkMax leftMotorInkakeMotoSparkMax;
    //private CANSparkFlex rightMotor;
    //private DutyCycleEncoder armEncoder;
    //private double encoderOffset = 0.7510;
    //private PIDController pidController;

   

    public Intake() {
        intakeMotor = new CANSparkMax(24, MotorType.kBrushless);
        intakeMotor.restoreFactoryDefaults();
        intakeMotor.setIdleMode(com.revrobotics.CANSparkBase.IdleMode.kBrake);
        //intakeMotor.setSmartCurrentLimit(Constants.IntakeConstants.currentLimit);
        //intakeMotor.enableVoltageCompensation(Constants.GeneralConstants.voltageComp);

        intakeMotor.burnFlash();

    }

    public Command intakeGamePiece() {
        return run(
            () -> {
                intakeMotor.set(Constants.IntakeConstants.motorSpeed);

            });

    }

    public Command outtakeGamePiece() {
        return run(
            () -> {
                intakeMotor.set(-Constants.IntakeConstants.motorSpeed);
            });
    }

    public Command stopIntake() {
        return run(
            () -> {
                intakeMotor.set(0);
            });
    }

}



        //Set default behaviour of the motor

       // leftMotorInkakeMotoSparkMax.setClosedLoopRampRate(0.5); //Optional Set ramp rate to prevent sudden movements

   // }

    //public void leftMotorInkakeMotoSparkMax(double fwdIntake) {
        //leftMotorInkakeMotoSparkMax.set(fwdIntake);
    //}

   

    
        //rightMotor = new CANSparkFlex(36, MotorType.kBrushless);
        //armEncoder = new DutyCycleEncoder(5);
        //armEncoder.setPositionOffset(encoderOffset);

        //pidController = new PIDController(Constants.ArmConstants.kP,
            //Constants.ArmConstants.kI,
            //Constants.ArmConstants.kD);
        
        ///pidController.setTolerance(0.002);

        //leftMotor.restoreFactoryDefaults();
        //rightMotor.restoreFactoryDefaults();

        //CANSparkMaxUtil.setCANSparkMaxBusUsage(leftMotor, Usage.kMinimal);
        //CANSparkMaxUtil.setCANSparkMaxBusUsage(rightMotor, Usage.kPositionOnly);

        //leftMotor.setSmartCurrentLimit(Constants.ArmConstants.currentLimit);
        //rightMotor.setSmartCurrentLimit(Constants.ArmConstants.currentLimit);

        //leftMotor.setIdleMode(IdleMode.kCoast);
        //rightMotor.setIdleMode(IdleMode.kCoast);

        //rightMotor.setInverted(false);
        //leftMotor.setInverted(false);

        //rightMotor.burnFlash();
        //leftMotor.burnFlash();

        //setPower(0);

    //}

    //@Override
    //public void periodic() {
        //SmartDashboard.putNumber("intakeEncoder", getPosition());
        //System.out.println(getPosition());
    //}



    /**
     * 
     * @return rotations
     */
    //public double getRawPosition() {
        //return leftMotorInkakeMotoSparkMaxEncoder.getAbsolutePosition();
    //}
    /**
     * 
     * @return degrees
     */
    //public double getPosition() {
       // return (leftMotorInkakeMotoSparkMax.getAbsolutePosition() - armEncoder.getPositionOffset())*360.0;
    //}

    //public void setPower(double power) {
        //leftMotorInkakeMotoSparkMax.set(power);
        //rightMotor.set(-power);
    //}

    /*
    public void setPosition(double setpoint) {
        setPower(pidController.calculate(getPosition(), setpoint));
    }
    */
    
//}